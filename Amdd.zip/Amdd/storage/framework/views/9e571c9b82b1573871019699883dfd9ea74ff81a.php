<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adhesion Message</title>
</head>
<body>
    <h1>Adhesion Message</h1>
    <p>Type: <?php echo e(isset($details['type']) && is_string($details['type']) ? $details['type'] : ''); ?></p>
    <p>Nom: <?php echo e(isset($details['nom']) && is_string($details['nom']) ? $details['nom'] : ''); ?></p>
    <p>Prénom: <?php echo e(isset($details['prenom']) && is_string($details['prenom']) ? $details['prenom'] : ''); ?></p>
    <p>Sexe: <?php echo e(isset($details['sexe']) && is_string($details['sexe']) ? $details['sexe'] : ''); ?></p>
    <p>Téléphone: <?php echo e(isset($details['telephone']) && is_string($details['telephone']) ? $details['telephone'] : ''); ?></p>
    <p>Email: <?php echo e(isset($details['email']) && is_string($details['email']) ? $details['email'] : ''); ?></p>
    <p>Mot de passe: <?php echo e(isset($details['mot_de_passe']) && is_string($details['mot_de_passe']) ? $details['mot_de_passe'] : ''); ?></p>
    <p>Région: <?php echo e(isset($details['region']) && is_string($details['region']) ? $details['region'] : ''); ?></p>
    <p>Ville: <?php echo e(isset($details['ville']) && is_string($details['ville']) ? $details['ville'] : ''); ?></p>
    <p>Profession: <?php echo e(isset($details['profession']) && is_string($details['profession']) ? $details['profession'] : ''); ?></p>
    <p>Spécialité: <?php echo e(isset($details['specialite']) && is_string($details['specialite']) ? $details['specialite'] : ''); ?></p>
    <p>Années d'expérience: <?php echo e(isset($details['annee_experience']) && is_string($details['annee_experience']) ? $details['annee_experience'] : ''); ?></p>
    <p>Niveau d'études: <?php echo e(isset($details['niveau_etude']) && is_string($details['niveau_etude']) ? $details['niveau_etude'] : ''); ?></p>
    <p>Niveau de compétence en matière de technologie et d'informatique: <?php echo e(isset($details['niveau_compétence_matière_technologie']) && is_string($details['niveau_compétence_matière_technologie']) ? $details['niveau_compétence_matière_technologie'] : ''); ?></p>
    <p>Âge: <?php echo e(isset($details['age']) && is_string($details['age']) ? $details['age'] : ''); ?></p>
    <p>Niveau de diplôme: <?php echo e(isset($details['niveau_diplome']) && is_string($details['niveau_diplome']) ? $details['niveau_diplome'] : ''); ?></p>
    <p>Spécialité 1: <?php echo e(isset($details['specialite1']) && is_string($details['specialite1']) ? $details['specialite1'] : ''); ?></p>
    <p>Type de diplôme: <?php echo e(isset($details['type_diplome']) && is_string($details['type_diplome']) ? $details['type_diplome'] : ''); ?></p>
    <p>Type de stage: <?php echo e(isset($details['type_stage']) && is_string($details['type_stage']) ? $details['type_stage'] : ''); ?></p>
    <p>Durée: <?php echo e(isset($details['duree']) && is_string($details['duree']) ? $details['duree'] : ''); ?></p>
    <p>Date de début: <?php echo e(isset($details['date_debut']) && is_string($details['date_debut']) ? $details['date_debut'] : ''); ?></p>
    <p>Date de fin: <?php echo e(isset($details['date_fin']) && is_string($details['date_fin']) ? $details['date_fin'] : ''); ?></p>
    <p>CV: <a href="<?php echo e(isset($details['cv']) ? $details['cv'] : '#'); ?>">Télécharger le CV</a></p>
    <p>Profiles: <?php echo e(isset($details['profiles']) && is_string($details['profiles']) ? $details['profiles'] : ''); ?></p>
    <p>Comment vous nous avez trouvé: <?php echo e(isset($details['competence_options']) && is_string($details['competence_options']) ? $details['competence_options'] : ''); ?></p>
    <p>CIN/Passport: <?php echo e(isset($details['cin']) && is_string($details['cin']) ? $details['cin'] : ''); ?></p>
</body>
</html>
<?php /**PATH C:\wamp64\www\Amdd\resources\views/emails/adhesionMail.blade.php ENDPATH**/ ?>