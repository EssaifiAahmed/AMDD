

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
  <h2 class="text-center mb-4">Contact Us</h2>
  <div class="contact-form" style="max-width: 400px;
      margin: auto;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 10px;
      background-color: #f9f9f9;
      margin-bottom: 90px;
      margin-left:40px;
      ">
  <?php if(Session::has('message_sent')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo e(Session::get('message_sent')); ?>

  </div>
  <?php endif; ?>
    <form action="<?php echo e(route('contact.send')); ?>" method="POST">
    <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="name">Name *</label>
        <input type="text" class="form-control" id="name" name="name" required>
      </div>
      <div class="form-group">
        <label for="email">Email *</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <div class="form-group">
        <label for="message">Message *   </label>
        <textarea class="form-control" id="msg" name="msg" rows="5" required></textarea>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Envoyer</button>
    </form>
    kshsbs
</div>
<div class="col-md-6">
            <!-- Image à côté du formulaire -->
            <img src="/assets/images/contact-img.png" alt="" style="float: left;
    margin-left: 100%;
    margin-top: -500px;
    margin-bottom:60px;
    "/>
        </div>
  </div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Amdd\resources\views/contact-us.blade.php ENDPATH**/ ?>