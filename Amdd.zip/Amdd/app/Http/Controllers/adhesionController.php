<?php

namespace App\Http\Controllers;
use App\Mail\adhesionMail;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class adhesionController extends Controller
{
    public function adhesion()
    {
        return view('adhesion');
    }

    
    public function sendEmail(Request $request)
{
    $details = [
        'type' => $request->type,
        'nom' => $request->nom,
        'prenom' => $request->prenom,
        'sexe' => $request->sexe,
        'telephone' => $request->telephone,
        'email' => $request->email,
        'mot_de_passe' => $request->mot_de_passe,
        'region' => $request->region,
        'ville' => $request->ville,
        'profession' => $request->profession,
        'specialite' => $request->specialite,
        'annee_experience' => $request->annee_experience,
        'niveau_etude' => $request->niveau_etude,
        'niveau_compétence_matière_technologie' => $request->niveau_compétence_matière_technologie,
        'age' => $request->age,
        'niveau_diplome' => $request->niveau_diplome,
        'specialite1' => $request->specialite1,
        'type_diplome' => $request->type_diplome,
        'type_stage' => $request->type_stage,
        'duree' => $request->duree,
        'date_debut' => $request->date_debut,
        'date_fin' => $request->date_fin,
        'cv' => $request->cv,
        'profiles' => $request->profiles,
        'competence_options' => $request->competence_options,
        'cin' => $request->cin,
    ];


        Mail::to('elmimounirajae59@gmail.com')->send(new adhesionMail($details));
        return back()->with('message_sent', 'Votre message a bien été envoyé !');
    }
}
